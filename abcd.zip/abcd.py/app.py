from flask import Flask, render_template, request
from signup import create_user
from login import check_user
from tree import *
from selfsortingarray import *

global USER 
USER=None
ADMIN=None

app = Flask(__name__)

@app.route('/')
def signup_form():
    return render_template('user_choice.html')

@app.route('/signup', methods=['POST'])
def signup():
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    
    print(create_user(name,email,password))
    
    return render_template('sign_up_successful.html')

@app.route('/userlogin')
def login_form():
    return render_template('user_login.html')

@app.route('/admin_login')
def admin_form():
    return render_template('admin_add_table.html')

@app.route('/add_table',methods=['POST'])
def add_table():
    table = request.form['block_name']
    ssa.insert(int(table))
    for i in ssa:
        print(i)
    return render_template('display_tables.html')

@app.route('/user_res',methods=['POST'])
def login():
    # Access the form data
    username = request.form['username']
    password = request.form['password']

    if check_user(username,password):
        return render_template('add_reservation.html')

@app.route('/reservation',methods=['POST'])
def reserve():
    seat = request.form['seat']
    date = request.form['date']
    hour = request.form['hour']
    minute = request.form['minute']
    booking_time=str(hour)+':'+str(minute)

    next_element = find_immediate_next_element(lst, int(seat))
    print('ejcieji',next_element)
    if next_element is None:
        print("No immediate next element found in the list")
    else:
        duration=1
        result = book_table(next_element, booking_time, duration)
        print(result)
    return render_template('reservation_successful.html')


if __name__ == '__main__':

    app.run(debug=True)

