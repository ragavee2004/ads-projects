
import pickle

# Load data from binary file
try:
    with open('user_data.bin', 'rb') as file:
        data = pickle.load(file)
        print(data)
except FileNotFoundError:
    print("File 'data.bin' not found.")

